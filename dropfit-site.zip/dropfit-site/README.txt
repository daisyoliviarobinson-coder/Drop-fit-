DROPFIT WEBSITE - SETUP

1. PUT IT ONLINE (free)
   Go to app.netlify.com/drop and drag this whole folder in. You get a live link in seconds.
   (GitHub Pages or Cloudflare Pages also work.)

2. TAKE PAYMENTS (£3.50/month Plus)
   - Create a subscription product on Stripe, Lemon Squeezy or Gumroad and copy its payment link.
   - Open play.html in a text editor, find PAY_LINK at the top of the script and paste the link between the quotes.
   - After someone pays, email them a code. Add each code to UNLOCK_CODES, e.g. ["PLUS-7K2M","PLUS-93QX"], then re-upload.
   IMPORTANT: codes live in the page source, so this is a basic MVP system. Anyone who views the source could find them. For real protection you need a login + server (ask me to build it).
   Until PAY_LINK is set, Plus cannot be bought and the paywall says payments aren't set up.

3. SHOW ADS
   Apply for Google AdSense with your live site. Once approved, paste your client id and ad slot into ADSENSE_CLIENT and ADSENSE_SLOT in play.html. Ads stay hidden until then. AdSense may reject very new, low-traffic sites; keep posting and re-apply.

4. BEFORE YOU LAUNCH
   - Put your email and the date in privacy.html.
   - Check the 10-games limit and paywall by playing 10 games.
   - Post clips of satisfying clears on TikTok/Reels with your link in your bio.
